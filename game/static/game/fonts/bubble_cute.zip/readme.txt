THIS FONT IS FREE FOR PERSONAL USE...
Commercial license font are available there :
andreyfontdesign@gmail.com

DOWNLOAD FULL VERSION:
https://www.creativefabrica.com/product/bubble-cute/ref/236642/

Paypal Account for donation (support me):
https://paypal.me/andreandesign

INDONESIA � MOHON DIBACA:
Halo, buat agency, designer, youtuber, atau siapa saja yang akan menggunakan font ini untuk kebutuhan KOMERSIL, seperti poster film, pamphlet, promo, logo perusahaan, kaos, dan sejenisnya bisa langsung membeli licensinya disaya. Silahkan menghubungi Instagram saya/ email
Tenang, harga bersahabat kok.
terimakasih

Menggunakan Font ini dengan lisensi "Personal Use" untuk kepentingan komersial apapun bentuknya TANPA IZIN dari kami, akan dikenakan biaya COROPORATE LICENSE.